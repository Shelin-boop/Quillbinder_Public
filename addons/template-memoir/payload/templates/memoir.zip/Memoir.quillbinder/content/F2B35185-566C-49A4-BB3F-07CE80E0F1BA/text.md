# Place
**When I was there:** 
**What it looked like:** 
**Sounds and smells:** 
**What happened there:** 
**Photos or documents:** 
