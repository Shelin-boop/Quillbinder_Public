Write a few lines about why you want to tell your story and who should read it. You can remove this document later, or keep it as a preface.
