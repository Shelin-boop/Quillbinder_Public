# Characters
NAME, a few words about them
# Setting
Where and when the play takes place.
