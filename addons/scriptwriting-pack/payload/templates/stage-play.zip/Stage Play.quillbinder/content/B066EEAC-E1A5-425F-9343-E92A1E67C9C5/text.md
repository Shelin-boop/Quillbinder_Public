# How this template works
The play lives in the folder **Play**, one document per scene, in folders for the acts.
## Writing in script mode
The documents in the script folder are scripts: their icon is yellow, and the footer of the editor shows the element of the line you are in.
- **Enter** at the end of a line goes on to the element that usually follows.
- **Tab** on an empty line changes the line to another element; after some elements it starts a different element on the next line or types a piece of text for you.
- **Enter** on an empty line opens the list of elements; press the letter of the one you want.
- While you type, names, places and stock phrases are offered in a small list. **Enter** or **Tab** takes the marked one, **Esc** closes the list.
## New documents
A new document inside a folder that holds scripts is a script as well. For other documents, switch script mode on or off with **Format > Scriptwriting > Script Mode** (Ctrl+8).
## Getting it out
**File > Compile** with the output *Fountain* or *Final Draft* gives a file for other screenwriting programs; *Word* or *PDF* with the format *Default (Editor Formatting)* keeps the layout you see here.
