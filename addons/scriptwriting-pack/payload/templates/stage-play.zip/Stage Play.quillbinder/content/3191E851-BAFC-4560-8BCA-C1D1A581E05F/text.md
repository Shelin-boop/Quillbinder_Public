::Script > Act Heading:: ACT ONE
::Script > Scene Heading:: SCENE 1
::Script > Stage Direction:: (Where we are, and who is on stage.)
::Script > Character:: NAME
::Script > Dialogue:: What is said.
::Script > Character:: OTHER NAME
::Script > Parenthetical:: (how it is said)
::Script > Dialogue:: The answer.
