::Script > Page:: PAGE ONE (four panels)
::Script > Panel:: Panel 1
::Script > Description:: What the artist should draw. Keep it to what can be seen.
::Script > Character:: NAME
::Script > Dialogue:: What is said.
::Script > Panel:: Panel 2
::Script > Description:: The next picture.
::Script > Caption:: CAPTION: A line of narration.
::Script > Sound Effect:: SFX: KRAK
