# Name
**Role in the story:** 
**Wants:** 
**Needs:** 
**Secret:** 
**How they speak:** 
**First seen in:** 
## Notes
