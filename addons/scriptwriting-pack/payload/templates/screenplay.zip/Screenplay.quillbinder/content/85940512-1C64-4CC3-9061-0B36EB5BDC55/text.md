# Location
**Interior or exterior:** 
**What it looks like:** 
**Sounds:** 
**Scenes set here:** 
## Notes
