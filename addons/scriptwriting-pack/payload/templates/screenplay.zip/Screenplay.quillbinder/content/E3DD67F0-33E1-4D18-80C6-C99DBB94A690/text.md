::Script > Scene Heading:: INT. PLACE - DAY
::Script > Action:: Describe what we see. Then press Tab on an empty line for a character.
::Script > Character:: NAME
::Script > Parenthetical:: (how it is said)
::Script > Dialogue:: What is said.
::Script > Action:: Replace this scene with your own.
